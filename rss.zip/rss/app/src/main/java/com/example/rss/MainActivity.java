package com.example.rss;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    ListView rssListView;

    String[] rssTitles = {
            "Python Program to Find the Length of a String",
            "Python Program to Find the Greatest of Three Numbers",
            "Python Program to Calculate the Power of a Number",
            "Python Program to Find the Median of a List",
            "Python Program to Find the Mode of a List",
            "Python Program to Find Unique Elements in a List",
            "Python Program to Find Common Elements in Two Lists",
            "Python Program To Check if Two Strings are Anagrams",
            "Python Program to Count the Frequency of Elements in a List",
            "Python Program to Find Union of Two Lists"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rssListView = findViewById(R.id.rssListView);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                rssTitles
        );

        rssListView.setAdapter(adapter);
    }
}