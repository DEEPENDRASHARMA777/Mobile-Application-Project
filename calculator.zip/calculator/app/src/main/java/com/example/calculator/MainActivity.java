package com.example.calculator;

//package com.example.calculatorapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class MainActivity extends AppCompatActivity {

    TextView tvInput, tvResult;
    String input = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvInput = findViewById(R.id.tvInput);
        tvResult = findViewById(R.id.tvResult);
    }

    public void onClick(View view) {
        Button button = (Button) view;
        String buttonText = button.getText().toString();

        switch (buttonText) {
            case "AC":
                input = "";
                break;
            case "C":
                if (!input.isEmpty()) {
                    input = input.substring(0, input.length() - 1);
                }
                break;
            case "=":
                calculate();
                return;
            default:
                input += buttonText;
        }

        tvInput.setText(input);
    }

    private void calculate() {
        ScriptEngine engine = new ScriptEngineManager().getEngineByName("rhino");
        try {
            Object result = engine.eval(input);
            tvResult.setText(result.toString());
        } catch (ScriptException e) {
            tvResult.setText("Error");
        }
    }
}